./forNotWindows.sh
rm test.zip
zip test.zip *
